# SEO audit for an agent

- Site: https://genomplus.ru/
- Scanned at: 2026-09-04T21:34:06.571Z
- Pages: 8
- Critical: 4, Recommended: 52, Passed: 34

## How to use this file

- This file is written for an AI agent. Hand it to your agent in Codex, Cursor or Claude together with the official uCoz MCP connected.
- Every issue has a stable code, the list of affected URLs and a recommendation.
- Template edits go through the official ucoz-mcp: read_template, patch_template, ftp_tool. Back up and show a diff before writing.
- Do not change canonical, redirects, robots.txt or Schema.org without the owner confirming.

## `meta.description_missing` (Critical)

Missing meta description

What to do: Add a unique page description.

Affected URLs (3):
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin
- https://genomplus.ru/biokhimichieskii_analiz_krovi

## `lighthouse.crawlable-anchors` (Critical)

Links are not crawlable

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `schema.jsonld_missing` (Recommended)

No JSON-LD structured data

What to do: Add Schema.org markup where it fits: WebSite, Organization, Product, FAQ.

Affected URLs (8):
- https://genomplus.ru/
- https://genomplus.ru/prais
- https://genomplus.ru/full-price
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin
- https://genomplus.ru/biokhimichieskii_analiz_krovi

## `schema.breadcrumbs_missing` (Recommended)

No BreadcrumbList markup

What to do: Add breadcrumbs with Schema markup: they show up in search results.

Affected URLs (7):
- https://genomplus.ru/prais
- https://genomplus.ru/full-price
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin
- https://genomplus.ru/biokhimichieskii_analiz_krovi

## `content.heading_order` (Recommended)

Heading levels skip a step

What to do: Headings must go in order: H3 after H2, not H4.

Affected URLs (6):
- https://genomplus.ru/
- https://genomplus.ru/prais
- https://genomplus.ru/full-price
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii
- https://genomplus.ru/analiz_krovi_na_fierritin

## `content.h1_missing` (Recommended)

Missing H1

What to do: Add one clear H1 heading.

Affected URLs (6):
- https://genomplus.ru/
- https://genomplus.ru/prais
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin

## `meta.title_length` (Recommended)

Title length outside the usual range

What to do: Aim for roughly 10 to 65 characters.

Affected URLs (3):
- https://genomplus.ru/prais
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii

## `links.internal_missing` (Recommended)

Internal link target is missing

What to do: Fix or remove the link.

Affected URLs (3):
- https://genomplus.ru/full-price
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii

## `og.og_description_missing` (Recommended)

Missing og:description

What to do: Add Open Graph metadata.

Affected URLs (3):
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin
- https://genomplus.ru/biokhimichieskii_analiz_krovi

## `tls.new_root` (Recommended)

Certificate chain uses a new Let’s Encrypt root (Generation Y)

What to do: Some older clients, notably Windows without recent updates, do not know this root yet and will show a warning. Make sure the server serves the full cross-signed chain and check the site on ssllabs.com.

Affected URLs (1):
- https://genomplus.ru

## `links.orphan_pages` (Recommended)

Pages with no incoming internal links

What to do: Link to them from the menu or from body text.

Affected URLs (1):
- https://genomplus.ru/normativ-dokument

## `lighthouse.performance_needs_work` (Recommended)

Performance: 35/100.

What to do: Review the Lighthouse recommendations and apply targeted fixes.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.accessibility_needs_work` (Recommended)

Accessibility: 86/100.

What to do: Review the Lighthouse recommendations and apply targeted fixes.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.best-practices_needs_work` (Recommended)

Best Practices: 54/100.

What to do: Review the Lighthouse recommendations and apply targeted fixes.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.unused-css-rules` (Recommended)

Reduce unused CSS (Est savings of 60 KiB)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.unminified-css` (Recommended)

Minify CSS (Est savings of 6 KiB)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.unused-javascript` (Recommended)

Reduce unused JavaScript (Est savings of 206 KiB)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.largest-contentful-paint` (Recommended)

Largest Contentful Paint (17.0 s)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.max-potential-fid` (Recommended)

Max Potential First Input Delay (2,130 ms)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.errors-in-console` (Recommended)

Browser errors were logged to the console

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.interactive` (Recommended)

Time to Interactive (26.2 s)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.deprecations` (Recommended)

Uses deprecated APIs (1 warning found)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.third-party-cookies` (Recommended)

Uses third-party cookies (15 cookies found)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.mainthread-work-breakdown` (Recommended)

Minimize main-thread work (13.6 s)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## `lighthouse.bootup-time` (Recommended)

Reduce JavaScript execution time (6.1 s)

What to do: Open the Lighthouse HTML report and apply the recommendation after checking how it affects templates.

Affected URLs (1):
- https://genomplus.ru/

## Engine service pages skipped: 2

Privacy policy, user agreement, checkout, 404 and other auto-generated pages. The owner does not edit them and they carry no SEO value.

- https://genomplus.ru/__privacy_policy
- https://genomplus.ru/__user_agreement
