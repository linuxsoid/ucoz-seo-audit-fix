# SEO-аудит для агента

- Сайт: https://genomplus.ru/
- Дата проверки: 2026-09-04T21:34:06.571Z
- Страниц: 8
- Критичные: 4, Рекомендации: 52, Пройдено: 34

## Как этим пользоваться

- Этот файл рассчитан на ИИ-агента. Отдайте его агенту в Codex, Cursor или Claude вместе с подключённым официальным uCoz MCP.
- Каждая проблема имеет постоянный код, список затронутых адресов и рекомендацию.
- Правки в шаблоны вносит официальный ucoz-mcp: read_template, patch_template, ftp_tool. Перед записью делайте backup и показывайте diff.
- Не меняйте canonical, редиректы, robots.txt и Schema.org без подтверждения владельца.

## `meta.description_missing` (Критичные)

Отсутствует meta description.

Что сделать: Добавьте уникальное описание страницы.

Затронутые адреса (3):
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin
- https://genomplus.ru/biokhimichieskii_analiz_krovi

## `lighthouse.crawlable-anchors` (Критичные)

Ссылки не всегда доступны поисковым роботам.

Что сделать: Используйте обычные href-ссылки для важных переходов.

Затронутые адреса (1):
- https://genomplus.ru/

## `schema.jsonld_missing` (Рекомендации)

Отсутствует структурированная разметка JSON-LD.

Что сделать: Добавьте Schema.org разметку WebSite, Organization, Article, Product или BreadcrumbList там, где это уместно.

Затронутые адреса (8):
- https://genomplus.ru/
- https://genomplus.ru/prais
- https://genomplus.ru/full-price
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin
- https://genomplus.ru/biokhimichieskii_analiz_krovi

## `schema.breadcrumbs_missing` (Рекомендации)

Нет разметки хлебных крошек BreadcrumbList.

Что сделать: Добавьте крошки со Schema-разметкой: они показываются в выдаче и помогают навигации.

Затронутые адреса (7):
- https://genomplus.ru/prais
- https://genomplus.ru/full-price
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin
- https://genomplus.ru/biokhimichieskii_analiz_krovi

## `content.heading_order` (Рекомендации)

Нарушена иерархия заголовков: H2 сразу на H6, H3 сразу на H6, H3 сразу на H5.

Что сделать: Уровни должны идти по порядку, без пропусков: за H2 идёт H3, а не H4.

Затронутые адреса (6):
- https://genomplus.ru/
- https://genomplus.ru/prais
- https://genomplus.ru/full-price
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii
- https://genomplus.ru/analiz_krovi_na_fierritin

## `content.h1_missing` (Рекомендации)

Отсутствует H1.

Что сделать: Добавьте один понятный заголовок H1.

Затронутые адреса (6):
- https://genomplus.ru/
- https://genomplus.ru/prais
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin

## `meta.title_length` (Рекомендации)

Длина title 82 символов: «Цены на анализы в Батайске | Геном плюс — единый центр приёма медицинских анализов»

Что сделать: Ориентир: примерно 10-65 символов.

Затронутые адреса (3):
- https://genomplus.ru/prais
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii

## `links.internal_missing` (Рекомендации)

Со страницы нет ссылок на другие страницы сайта.

Что сделать: Добавьте внутренние ссылки на важные страницы: иначе и посетитель, и поисковик попадают в тупик.

Затронутые адреса (3):
- https://genomplus.ru/full-price
- https://genomplus.ru/normativ-dokument
- https://genomplus.ru/novosti-akcii

## `og.og_description_missing` (Рекомендации)

Отсутствует og:description.

Что сделать: Добавьте Open Graph метаданные.

Затронутые адреса (3):
- https://genomplus.ru/analiz_krovi_na_fierritin
- https://genomplus.ru/analiz_na_kholistierin
- https://genomplus.ru/biokhimichieskii_analiz_krovi

## `tls.new_root` (Рекомендации)

В цепочке сертификата есть новый корень Let’s Encrypt поколения Y: genomplus.ru <- YR1 <- Root YR <- ISRG Root X1

Что сделать: Часть старых клиентов, особенно Windows без свежих обновлений, этот корень ещё не знает и покажет предупреждение. Убедитесь, что сервер отдаёт полную цепочку с кросс-подписью, и проверьте сайт на ssllabs.com.

Затронутые адреса (1):
- https://genomplus.ru

## `links.orphan_pages` (Рекомендации)

Найдены страницы без внутренних ссылок: 5.

Что сделать: Сошлитесь на них из меню или из текста других страниц, иначе поиск их почти не видит.

Затронутые адреса (1):
- https://genomplus.ru/normativ-dokument

## `lighthouse.performance_needs_work` (Рекомендации)

Производительность: 35/100.

Что сделать: Посмотрите рекомендации Lighthouse и внесите точечные правки.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.accessibility_needs_work` (Рекомендации)

Доступность: 86/100.

Что сделать: Посмотрите рекомендации Lighthouse и внесите точечные правки.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.best-practices_needs_work` (Рекомендации)

Best Practices: 54/100.

Что сделать: Посмотрите рекомендации Lighthouse и внесите точечные правки.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.unused-css-rules` (Рекомендации)

Лишний CSS (примерная экономия: 60 КиБ).

Что сделать: Разделите глобальные стили и стили отдельных модулей, чтобы не грузить лишний CSS на каждой странице.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.unminified-css` (Рекомендации)

CSS не минифицирован (примерная экономия: 6 КиБ).

Что сделать: Подключайте минифицированные CSS-файлы или минифицируйте пользовательские стили перед загрузкой на FTP.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.unused-javascript` (Рекомендации)

Лишний JavaScript (примерная экономия: 206 КиБ).

Что сделать: Уберите неиспользуемые скрипты, отложите необязательные виджеты и проверьте, какие JS-файлы подключаются в глобальных шаблонах.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.largest-contentful-paint` (Рекомендации)

Крупнейший элемент первого экрана (17.0 с).

Что сделать: Оптимизируйте главный элемент первого экрана и ресурсы, от которых зависит его появление.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.max-potential-fid` (Рекомендации)

Max Potential First Input Delay (2,130 мс).

Что сделать: Откройте HTML-отчет Lighthouse и примените рекомендацию после проверки влияния на шаблоны.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.errors-in-console` (Рекомендации)

Browser errors were logged to the console.

Что сделать: Откройте HTML-отчет Lighthouse и примените рекомендацию после проверки влияния на шаблоны.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.interactive` (Рекомендации)

Time to Interactive (26.2 с).

Что сделать: Откройте HTML-отчет Lighthouse и примените рекомендацию после проверки влияния на шаблоны.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.deprecations` (Рекомендации)

Uses deprecated APIs (1 warning found).

Что сделать: Откройте HTML-отчет Lighthouse и примените рекомендацию после проверки влияния на шаблоны.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.third-party-cookies` (Рекомендации)

Uses third-party cookies (15 cookies found).

Что сделать: Откройте HTML-отчет Lighthouse и примените рекомендацию после проверки влияния на шаблоны.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.mainthread-work-breakdown` (Рекомендации)

Minimize main-thread work (13.6 с).

Что сделать: Откройте HTML-отчет Lighthouse и примените рекомендацию после проверки влияния на шаблоны.

Затронутые адреса (1):
- https://genomplus.ru/

## `lighthouse.bootup-time` (Рекомендации)

Reduce JavaScript execution time (6.1 с).

Что сделать: Откройте HTML-отчет Lighthouse и примените рекомендацию после проверки влияния на шаблоны.

Затронутые адреса (1):
- https://genomplus.ru/

## Служебные страницы движка пропущены: 2

Политика, соглашение, оформление заказа, страница 404 и прочие автогенерируемые страницы. Владелец их не редактирует, SEO-ценности нет.

- https://genomplus.ru/__privacy_policy
- https://genomplus.ru/__user_agreement
